<?php
require_once '../config/cors.php'; 
// Memanggil konfigurasi CORS agar API bisa diakses dari aplikasi lain

require_once '../config/database.php'; 
// Memanggil file koneksi database

$data = json_decode(file_get_contents("php://input"), true); 
// Mengambil data JSON dari request body dan mengubahnya menjadi array

if (!$data) { 
    // Mengecek apakah data JSON tidak valid
    echo json_encode([
        "success" => false,
        "message" => "JSON tidak valid"
    ]);
    exit; 
    // Menghentikan proses jika JSON tidak valid
}

$user_id = $data['user_id'] ?? null; 
// Mengambil user_id dari JSON (jika tidak ada, isi null)

$title   = $data['title'] ?? null; 
// Mengambil judul note dari JSON

$content = $data['content'] ?? null; 
// Mengambil isi note dari JSON

$image   = $data['image'] ?? null; 
// Mengambil URL gambar (opsional)

if (!$user_id || !$title || !$content) { 
    // Validasi: memastikan data wajib tidak kosong
    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);
    exit; 
    // Menghentikan proses jika data tidak lengkap
}

$stmt = $conn->prepare(
    "INSERT INTO notes (user_id, title, content, image) VALUES (?, ?, ?, ?)"
); 
// Menyiapkan query INSERT menggunakan prepared statement (aman dari SQL Injection)

$stmt->bind_param("isss", $user_id, $title, $content, $image); 
// Mengikat parameter ke query (i = integer, s = string)

if ($stmt->execute()) { 
    // Menjalankan query INSERT
    echo json_encode([
        "success" => true
    ]);
    // Mengirim response sukses jika data berhasil disimpan
} else {
    echo json_encode([
        "success" => false,
        "message" => $stmt->error
    ]);
    // Mengirim response gagal jika terjadi error
}
