<?php
// Membuat koneksi ke database MySQL
$conn = new mysqli(
    "localhost", // Host database
    "tommy",     // Username database
    "1802005",   // Password database
    "notes"      // Nama database
);

// Mengecek koneksi database
if ($conn->connect_error) {
    die("Database error");
}
